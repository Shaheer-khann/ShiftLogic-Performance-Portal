<?php

// Namespace declaration — this controller lives in app/Http/Controllers/
namespace App\Http\Controllers;

// Import the Mechanic model so we can query the mechanics table
use App\Models\Mechanic;

// Import the Department model so we can fetch departments for dropdown menus
use App\Models\Department;

// Import the base Controller class
use App\Http\Controllers\Controller;

// Import the Request class — Laravel injects this to give us access to form data
use Illuminate\Http\Request;

// CrewController handles all pages and actions related to mechanics
// The --resource flag gave us the 7 CRUD method stubs; we fill them here
class CrewController extends Controller
{
    // ---------------------------------------------------------------
    // index() — called by GET /crew
    // Displays the full crew directory table listing all mechanics
    // ---------------------------------------------------------------
    public function index()
    {
        // Mechanic::with('department') uses eager loading to fetch all mechanics
        // AND their related department in just 2 database queries (not N+1)
        // ->orderBy('id') sorts results by id column in ascending order
        // ->get() executes the query and returns a Collection (like an array of objects)
        $mechanics = Mechanic::with('department')->orderBy('id')->get();

        // Department::with('mechanics') eager-loads each department AND its mechanics
        // so we can call $dept->mechanics->count() in the view without extra queries
        // ->orderBy('name') sorts departments alphabetically
        $departments = Department::with('mechanics')->orderBy('name')->get();

        // compact() creates the array ['mechanics' => $mechanics, 'departments' => $departments]
        // Both variables are now available inside crew/index.blade.php
        return view('crew.index', compact('mechanics', 'departments'));
    }

    // ---------------------------------------------------------------
    // create() — called by GET /crew/create
    // Shows the "Add New Mechanic" form with a departments dropdown
    // ---------------------------------------------------------------
    public function create()
    {
        // Department::orderBy('name')->get() fetches all departments sorted alphabetically
        // We pass these to the view to populate the department <select> dropdown
        $departments = Department::orderBy('name')->get();

        // Pass $departments into the crew/create view
        return view('crew.create', compact('departments'));
    }

    // ---------------------------------------------------------------
    // store(Request $request) — called by POST /crew
    // Validates and saves a new mechanic submitted from the create form
    // ---------------------------------------------------------------
    public function store(Request $request)
    {
        // validate() checks all form fields against the rules below
        // If ANY rule fails, Laravel automatically redirects back to the form
        // with the validation errors and the old input — no extra code needed
        $validated = $request->validate([
            // 'name' must be present and not empty, and at least 3 characters long
            'name'          => 'required|min:3',

            // 'role' must be present and not empty (e.g. "Lead Mechanic")
            'role'          => 'required',

            // 'specialism' must be present and not empty (e.g. "Engine Rebuilds")
            'specialism'    => 'required',

            // 'experience' must be a whole number between 0 and 50
            'experience'    => 'required|integer|min:0|max:50',

            // 'email' must be present and in a valid email format
            'email'         => 'required|email',

            // 'status' must be exactly one of these three allowed values
            'status'        => 'required|in:Active,On Leave,Inactive',

            // 'department_id' is optional (nullable) but if provided must
            // exist as an id in the departments table — prevents fake IDs
            'department_id' => 'nullable|exists:departments,id',
        ]);

        // Mechanic::create() inserts a new row using only the validated data
        // We use $validated (not $request->all()) for security
        Mechanic::create($validated);

        // redirect() sends the browser to a different URL
        // ->route('crew.index') generates the URL for the crew index page
        // ->with('success', '...') flashes a one-time success message to the session
        // The view can then display this message to the user
        return redirect()->route('crew.index')->with('success', 'Mechanic added successfully!');
    }

    // ---------------------------------------------------------------
    // show() — called by GET /crew/{id}
    // We do not need a show page in this project so we redirect to index
    // ---------------------------------------------------------------
    public function show(Mechanic $mechanic)
    {
        // Redirect any direct URL visit to /crew/{id} back to the full crew list
        return redirect()->route('crew.index');
    }

    // ---------------------------------------------------------------
    // edit(Mechanic $mechanic) — called by GET /crew/{id}/edit
    // Shows the edit form pre-filled with this mechanic's existing data
    // Laravel's route model binding automatically fetches the mechanic by id
    // ---------------------------------------------------------------
    public function edit(Mechanic $mechanic)
    {
        // Fetch all departments again so the dropdown can be populated
        $departments = Department::orderBy('name')->get();

        // Pass both $mechanic (the existing data) and $departments (dropdown options)
        // into the crew/edit view
        return view('crew.edit', compact('mechanic', 'departments'));
    }

    // ---------------------------------------------------------------
    // update(Request $request, Mechanic $mechanic) — called by PUT /crew/{id}
    // Validates and saves the edited data for an existing mechanic
    // ---------------------------------------------------------------
    public function update(Request $request, Mechanic $mechanic)
    {
        // Same validation rules as store() — the form fields are identical
        $validated = $request->validate([
            'name'          => 'required|min:3',
            'role'          => 'required',
            'specialism'    => 'required',
            'experience'    => 'required|integer|min:0|max:50',
            'email'         => 'required|email',
            'status'        => 'required|in:Active,On Leave,Inactive',
            'department_id' => 'nullable|exists:departments,id',
        ]);

        // $mechanic->update() runs an SQL UPDATE on the existing row
        // using only the validated data from the form
        $mechanic->update($validated);

        // Redirect back to the crew index with a success flash message
        return redirect()->route('crew.index')->with('success', 'Mechanic updated successfully!');
    }

    // ---------------------------------------------------------------
    // destroy(Mechanic $mechanic) — called by DELETE /crew/{id}
    // Permanently deletes a mechanic record from the database
    // ---------------------------------------------------------------
    public function destroy(Mechanic $mechanic)
    {
        // $mechanic->delete() runs SQL DELETE to remove this row from the mechanics table
        $mechanic->delete();

        // Redirect back to the crew list with a success message
        return redirect()->route('crew.index')->with('success', 'Mechanic removed successfully!');
    }
}
