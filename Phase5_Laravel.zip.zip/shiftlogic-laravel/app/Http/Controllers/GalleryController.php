<?php

// Namespace declaration — this controller lives in app/Http/Controllers/
namespace App\Http\Controllers;

// Import the Gallery model so we can query the gallery table
use App\Models\Gallery;

// Import the base Controller class
use App\Http\Controllers\Controller;

// Import the Request class to access submitted form data and uploaded files
use Illuminate\Http\Request;

// Import the Storage facade — this gives us methods to save and delete files
// from the filesystem (like saving uploaded images to storage/app/public/)
use Illuminate\Support\Facades\Storage;

// GalleryController handles the supercar build photo gallery
class GalleryController extends Controller
{
    // ---------------------------------------------------------------
    // index() — called by GET /gallery
    // Shows all gallery photos, newest first
    // ---------------------------------------------------------------
    public function index()
    {
        // Gallery::latest() orders by the created_at timestamp, newest first
        // This is equivalent to ->orderBy('created_at', 'desc')
        // ->get() executes the query and returns a Collection of Gallery objects
        $photos = Gallery::latest()->get();

        // Load gallery/index.blade.php and pass $photos to it
        return view('gallery.index', compact('photos'));
    }

    // ---------------------------------------------------------------
    // create() — called by GET /gallery/upload
    // Shows the image upload form
    // ---------------------------------------------------------------
    public function create()
    {
        // Simply return the upload form view — no data needed from the database
        return view('gallery.create');
    }

    // ---------------------------------------------------------------
    // store(Request $request) — called by POST /gallery
    // Validates, saves the uploaded image file, and creates the database record
    // ---------------------------------------------------------------
    public function store(Request $request)
    {
        // Validate all form fields before doing anything with the file
        $validated = $request->validate([
            // 'title' must be present and no longer than 150 characters
            'title'       => 'required|max:150',

            // 'description' is optional — nullable means it can be left empty
            'description' => 'nullable',

            // 'image' must be present, must be an actual image file (jpg/png/gif etc),
            // and must be no larger than 2048 kilobytes (2 MB)
            'image'       => 'required|image|max:2048',
        ]);

        // $request->file('image') gets the uploaded file object from the form
        // ->store('gallery', 'public') saves the file inside storage/app/public/gallery/
        // Laravel auto-generates a unique filename to prevent collisions
        // The return value is the relative path e.g. "gallery/abc123xyz.jpg"
        $path = $request->file('image')->store('gallery', 'public');

        // Gallery::create() inserts a new row into the gallery table
        // We use the validated title and description, plus the file path we just saved
        Gallery::create([
            'title'       => $validated['title'],       // the photo title from the form
            'description' => $validated['description'], // optional description (can be null)
            'image_path'  => $path,                     // the storage path returned by ->store()
        ]);

        // Redirect to the gallery index page with a success flash message
        return redirect()->route('gallery.index')->with('success', 'Photo uploaded successfully!');
    }

    // ---------------------------------------------------------------
    // destroy(Gallery $gallery) — called by DELETE /gallery/{id}
    // Deletes the image file from storage AND the record from the database
    // ---------------------------------------------------------------
    public function destroy(Gallery $gallery)
    {
        // Storage::disk('public')->delete() removes the actual image file
        // from storage/app/public/ using the path stored in the database column
        // This prevents orphaned files building up in storage after records are deleted
        Storage::disk('public')->delete($gallery->image_path);

        // $gallery->delete() removes the database row from the gallery table
        $gallery->delete();

        // Redirect back to the gallery list with a success flash message
        return redirect()->route('gallery.index')->with('success', 'Photo deleted successfully!');
    }
}
