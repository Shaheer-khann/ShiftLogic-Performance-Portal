<?php

// Namespace declaration — tells Laravel this controller lives in app/Http/Controllers/
namespace App\Http\Controllers;

// Import the base Controller class that all our controllers extend from
use App\Http\Controllers\Controller;

// The HomeController handles requests for the main landing page of ShiftLogic
class HomeController extends Controller
{
    // index() is called when a user visits the root URL: GET /
    // It has no database queries — the landing page has static content
    public function index()
    {
        // view('home') tells Laravel to look for resources/views/home.blade.php
        // and return it as the HTTP response sent to the browser
        return view('home');
    }
}
