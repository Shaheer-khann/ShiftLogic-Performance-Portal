<?php

// Namespace declaration — this controller lives in app/Http/Controllers/
namespace App\Http\Controllers;

// Import the Part model so we can query the parts table
use App\Models\Part;

// Import the base Controller class
use App\Http\Controllers\Controller;

// PartsController handles the performance parts catalogue page
class PartsController extends Controller
{
    // ---------------------------------------------------------------
    // index() — called by GET /parts
    // Fetches all parts from the database and sends them to the view
    // ---------------------------------------------------------------
    public function index()
    {
        // Part::orderBy('category') first groups parts by their category
        // ->orderBy('name') then sorts alphabetically within each category
        // ->get() executes the query and returns a Collection of Part objects
        $parts = Part::orderBy('category')->orderBy('name')->get();

        // Load the parts/index.blade.php view and pass $parts to it
        // compact('parts') is shorthand for ['parts' => $parts]
        return view('parts.index', compact('parts'));
    }
}
