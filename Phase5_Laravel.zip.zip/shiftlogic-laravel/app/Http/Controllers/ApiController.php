<?php

// Namespace declaration — this controller lives in app/Http/Controllers/
namespace App\Http\Controllers;

// Import the Part model so we can query the parts table
use App\Models\Part;

// Import the base Controller class
use App\Http\Controllers\Controller;

// ApiController handles all JSON API endpoints for ShiftLogic
// These routes return raw JSON data instead of HTML views
class ApiController extends Controller
{
    // ---------------------------------------------------------------
    // parts() — called by GET /api/parts
    // Returns all performance parts as a structured JSON response
    // ---------------------------------------------------------------
    public function parts()
    {
        // Part::orderBy('category') sorts parts by category alphabetically
        // ->get() runs the SELECT query and returns a Collection of Part objects
        $parts = Part::orderBy('category')->get();

        // response()->json() converts the array to JSON and sends it
        // with the correct Content-Type: application/json header automatically
        // This is the standard format for a REST API response:
        // - 'status' => 'success' tells the caller the request worked
        // - 'count' => $parts->count() tells how many items are in the response
        // - 'data' => $parts sends the actual array of part objects as JSON
        return response()->json([
            'status' => 'success',      // indicates the request completed without errors
            'count'  => $parts->count(), // the total number of parts returned
            'data'   => $parts,          // the full array of part objects (auto-serialized to JSON)
        ]);
    }
}
