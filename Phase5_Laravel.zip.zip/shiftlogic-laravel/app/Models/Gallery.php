<?php

// Namespace declaration — tells Laravel this file lives in app/Models/
namespace App\Models;

// Import the base Eloquent Model class
use Illuminate\Database\Eloquent\Model;

// Define the Gallery class, extending Model to get all Eloquent features
class Gallery extends Model
{
    // $table explicitly names the database table this model maps to
    // We write this because Laravel would guess "galleries" by default
    // but our migration created the table as "gallery" (without the s)
    protected $table = 'gallery';

    // $fillable lists every column that is allowed to be mass-assigned
    // These match the column names defined in the create_gallery_table migration
    protected $fillable = [
        'title',       // the photo's title e.g. "Nissan GT-R Track Build"
        'description', // optional longer text about the photo — can be null
        'image_path',  // the file path to the uploaded photo e.g. "images/gtr.jpg"
    ];

    // The Gallery model has no relationships in this project —
    // gallery items are standalone image records not linked to other tables
}
