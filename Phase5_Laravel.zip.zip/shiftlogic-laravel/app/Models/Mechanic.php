<?php

// Namespace declaration — tells Laravel this file lives in app/Models/
namespace App\Models;

// Import the base Eloquent Model class
use Illuminate\Database\Eloquent\Model;

// Define the Mechanic class, extending Model to get all Eloquent features
class Mechanic extends Model
{
    // $table explicitly names the database table this model maps to
    protected $table = 'mechanics';

    // $fillable lists every column that is allowed to be mass-assigned
    // These match the column names defined in the create_mechanics_table migration
    protected $fillable = [
        'department_id', // the foreign key linking this mechanic to a department
        'name',          // the mechanic's full name e.g. "Darya Khan"
        'role',          // their job title e.g. "Lead Mechanic"
        'specialism',    // their area of expertise e.g. "Engine Rebuilds"
        'experience',    // integer — number of years of experience
        'email',         // their contact email address
        'status',        // their current status: "Active", "On Leave", or "Inactive"
    ];

    // This method defines the inverse relationship: one Mechanic BELONGS TO one Department
    // It matches the department_id foreign key column on the mechanics table
    // When you call $mechanic->department you get the Department object for that mechanic
    public function department()
    {
        // belongsTo() takes the related model class name as its first argument
        // Laravel will automatically use department_id to find the matching department
        return $this->belongsTo(Department::class);
    }
}
