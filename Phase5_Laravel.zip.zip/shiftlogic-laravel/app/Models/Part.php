<?php

// Namespace declaration — tells Laravel this file lives in app/Models/
namespace App\Models;

// Import the base Eloquent Model class
use Illuminate\Database\Eloquent\Model;

// Define the Part class, extending Model to get all Eloquent features
class Part extends Model
{
    // $table explicitly names the database table this model maps to
    protected $table = 'parts';

    // $fillable lists every column that is allowed to be mass-assigned
    // These match the column names defined in the create_parts_table migration
    protected $fillable = [
        'name',           // the part's product name e.g. "Garrett GTX3582R Turbocharger"
        'category',       // what type of part it is e.g. "Forced Induction"
        'price',          // the price stored as a decimal e.g. 1850.00
        'condition_type', // whether the part is "New" or "Used"
        'description',    // a longer text description of what the part does
        'specs',          // technical specifications text e.g. "Compressor: 58mm | Max Boost: 30psi"
    ];

    // $casts tells Eloquent how to automatically convert column values
    // when you read them from the database — here price is returned as a float
    // so you get 1850.0 instead of the string "1850.00"
    protected $casts = [
        'price' => 'float', // cast the price decimal column to a PHP float number
    ];

    // The Part model has no relationships in this project —
    // parts are standalone items not linked to other tables
}
