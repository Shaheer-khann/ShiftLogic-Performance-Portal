<?php

// Every Laravel model file starts with this namespace declaration
// It tells Laravel this file lives inside the app/Models folder
namespace App\Models;

// We import the base Model class that all Eloquent models extend from
// This gives our class all the database query power (::all(), ::find(), etc.)
use Illuminate\Database\Eloquent\Model;

// We define our Department class and extend Model
// Extending Model means Department inherits all Eloquent features automatically
class Department extends Model
{
    // $table tells Eloquent exactly which database table this model represents
    // Without this, Laravel would guess "departments" from the class name anyway,
    // but being explicit is always clearer for beginners reading the code
    protected $table = 'departments';

    // $fillable is a security whitelist — it lists which columns are allowed
    // to be mass-assigned (e.g. Department::create([...]) )
    // Any column NOT in this list will be silently ignored during create/update
    // This protects against "mass assignment" security attacks
    protected $fillable = [
        'name',         // the department's display name e.g. "Engine & Powertrain Team"
        'description',  // an optional longer description of what the department does
    ];

    // This method defines the relationship: one Department HAS MANY Mechanics
    // It matches the foreign key department_id on the mechanics table
    // When you call $department->mechanics you get all mechanics in that department
    public function mechanics()
    {
        // hasMany() takes the related model class name as its first argument
        // Laravel will automatically look for department_id on the mechanics table
        return $this->hasMany(Mechanic::class);
    }
}
