<?php

// Namespace declaration — this seeder lives in the database/seeders folder
namespace Database\Seeders;

// Import our four custom model classes so we can use them to insert data
use App\Models\Department; // the Department model — maps to the departments table
use App\Models\Mechanic;   // the Mechanic model — maps to the mechanics table
use App\Models\Part;       // the Part model — maps to the parts table
use App\Models\Gallery;    // the Gallery model — maps to the gallery table

// Import the base Seeder class that our DatabaseSeeder extends from
use Illuminate\Database\Seeder;

// DatabaseSeeder is the main entry-point seeder that Laravel calls
// when you run: php artisan db:seed
class DatabaseSeeder extends Seeder
{
    // The run() method is what Laravel executes when seeding
    // All our data-insertion code goes inside this method
    public function run(): void
    {
        // ============================================================
        // STEP 1 — SEED DEPARTMENTS FIRST
        // We must insert departments before mechanics because mechanics
        // need a valid department_id — a foreign key pointing to this table
        // ============================================================

        // Department::create() inserts one row into the departments table
        // and returns the newly created Department object (with its auto id)
        $engine = Department::create([
            'name'        => 'Engine & Powertrain Team',              // department display name
            'description' => 'Handles all engine builds, rebuilds, and powertrain upgrades.', // optional description
        ]);

        // $chassis will hold the created Chassis department object
        // We store it in a variable so we can use $chassis->id below
        $chassis = Department::create([
            'name'        => 'Chassis & Suspension Team',
            'description' => 'Manages suspension geometry, coilover setups, and alignment.',
        ]);

        // $electronics holds the Electronics & ECU department object
        $electronics = Department::create([
            'name'        => 'Electronics & ECU Team',
            'description' => 'Responsible for ECU mapping, wiring, and electronics installs.',
        ]);

        // $race holds the Race Operations department object
        $race = Department::create([
            'name'        => 'Race Operations & Pit Crew',
            'description' => 'Covers race-day preparation, telemetry review, and pit operations.',
        ]);


        // ============================================================
        // STEP 2 — SEED MECHANICS (after departments so IDs exist)
        // Each mechanic is assigned to a department using ->id
        // ->id reads the auto-incremented primary key of the saved object
        // ============================================================

        // Mechanic 1: Darya Khan — Lead Mechanic in the Engine department
        Mechanic::create([
            'department_id' => $engine->id,     // links to the Engine & Powertrain department
            'name'          => 'Darya Khan',     // mechanic's full name
            'role'          => 'Lead Mechanic',  // their job title
            'specialism'    => 'Engine Rebuilds',// their area of technical expertise
            'experience'    => 12,               // years of experience as an integer
            'email'         => 'darya@shiftlogic.com', // contact email address
            'status'        => 'Active',         // current working status
        ]);

        // Mechanic 2: Samandar Malik — Suspension Engineer in Chassis department
        Mechanic::create([
            'department_id' => $chassis->id,             // links to the Chassis & Suspension department
            'name'          => 'Samandar Malik',          // mechanic's full name
            'role'          => 'Suspension Engineer',     // their job title
            'specialism'    => 'Chassis Tuning',          // their area of expertise
            'experience'    => 8,                         // 8 years experience
            'email'         => 'samandar@shiftlogic.com', // contact email
            'status'        => 'Active',                  // currently working
        ]);

        // Mechanic 3: Palwasha Khan — ECU Specialist in Electronics department
        Mechanic::create([
            'department_id' => $electronics->id,          // links to the Electronics & ECU department
            'name'          => 'Palwasha Khan',            // mechanic's full name
            'role'          => 'ECU Specialist',           // their job title
            'specialism'    => 'Engine Mapping',           // their area of expertise
            'experience'    => 6,                          // 6 years experience
            'email'         => 'palwasha@shiftlogic.com',  // contact email
            'status'        => 'On Leave',                 // currently on leave (not active)
        ]);

        // Mechanic 4: Gul Khan — Turbo Technician in Engine department
        Mechanic::create([
            'department_id' => $engine->id,           // also in Engine & Powertrain department
            'name'          => 'Gul Khan',             // mechanic's full name
            'role'          => 'Turbo Technician',     // their job title
            'specialism'    => 'Forced Induction',     // their area of expertise
            'experience'    => 5,                      // 5 years experience
            'email'         => 'gul@shiftlogic.com',   // contact email
            'status'        => 'Active',               // currently working
        ]);

        // Mechanic 5: Tipu Sultan — Pit Crew Chief in Race Operations department
        Mechanic::create([
            'department_id' => $race->id,                  // links to Race Operations & Pit Crew department
            'name'          => 'Tipu Sultan',               // mechanic's full name
            'role'          => 'Pit Crew Chief',            // their job title
            'specialism'    => 'Race-day Operations',       // their area of expertise
            'experience'    => 10,                          // 10 years experience
            'email'         => 'tipu@shiftlogic.com',       // contact email
            'status'        => 'Active',                    // currently working
        ]);


        // ============================================================
        // STEP 3 — SEED PERFORMANCE PARTS
        // Parts are standalone — no foreign keys needed
        // These were previously hardcoded inside js/main.js in the legacy app
        // Now they live properly in the database
        // ============================================================

        // Part 1: Garrett GTX3582R Turbocharger
        Part::create([
            'name'           => 'Garrett GTX3582R Turbocharger',                        // product name
            'category'       => 'Forced Induction',                                      // part category
            'price'          => 1850.00,                                                  // price in PKR/USD as decimal
            'condition_type' => 'New',                                                    // whether the part is new or used
            'description'    => 'Ball-bearing turbo with billet wheel. Supports up to 700whp. Ideal for high-revving engines needing fast spool.', // full description
            'specs'          => 'Compressor: 58mm | Turbine: 63mm | Max Boost: 30psi | Weight: 8.2kg', // technical specs
        ]);

        // Part 2: Wiseco Forged Piston Set
        Part::create([
            'name'           => 'Wiseco Forged Piston Set',
            'category'       => 'Engine Internals',
            'price'          => 620.00,
            'condition_type' => 'New',
            'description'    => 'High-silicon forged aluminum pistons for extreme heat and pressure tolerance. CNC-machined to exacting tolerances.',
            'specs'          => 'Material: 2618 Alloy | Compression: 9.5:1 | Bore Size: 86mm | Set of: 4',
        ]);

        // Part 3: Ohlins TTX36 Coilover Kit
        Part::create([
            'name'           => 'Ohlins TTX36 Coilover Kit',
            'category'       => 'Suspension',
            'price'          => 3200.00,
            'condition_type' => 'New',
            'description'    => 'Full coilover kit with twin-tube technology. 30-way damping adjustment for both track and road configurations.',
            'specs'          => 'Type: Twin-tube | Adjustment: 30-way | Spring Rate F/R: 10k/8k | Height Adjustable: Yes',
        ]);

        // Part 4: Brembo GT Big Brake Kit
        Part::create([
            'name'           => 'Brembo GT Big Brake Kit',
            'category'       => 'Braking',
            'price'          => 2100.00,
            'condition_type' => 'New',
            'description'    => 'Monoblock 6-piston front calipers with 380mm two-piece rotors. Massive heat dissipation for track use.',
            'specs'          => 'Pistons: 6F / 4R | Rotor Size: 380mm F / 355mm R | Material: Aluminum | Finish: Red',
        ]);

        // Part 5: HKS Hi-Power Titanium Exhaust
        Part::create([
            'name'           => 'HKS Hi-Power Titanium Exhaust',
            'category'       => 'Exhaust',
            'price'          => 1450.00,
            'condition_type' => 'New',
            'description'    => 'Full titanium cat-back exhaust system. Reduces weight by 9kg over stock while increasing flow and sound.',
            'specs'          => 'Material: Grade 1 Titanium | Pipe Diameter: 76mm | Weight Saving: 9kg | Fitment: Universal',
        ]);

        // Part 6: AEM Series 2 EMS
        Part::create([
            'name'           => 'AEM Series 2 EMS',
            'category'       => 'ECU & Electronics',
            'price'          => 980.00,
            'condition_type' => 'New',
            'description'    => 'Full standalone engine management system. Controls fuel, ignition, boost, and launch control with full data logging.',
            'specs'          => 'Inputs: 20 | Outputs: 16 | Data Log: 100hr | Comms: USB + CAN | Display: Compatible',
        ]);

    }
    // End of run() method — all data has been inserted
}
