<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    // Adds department_id foreign key to mechanics table
    // This creates the one department has many mechanics relationship
    public function up(): void
    {
        Schema::table('mechanics', function (Blueprint $table) {

            // nullable() means a mechanic can exist without a department
            // after() puts this column right after the id column
            $table->foreignId('department_id')
                  ->nullable()
                  ->after('id')
                  ->constrained('departments')
                  ->nullOnDelete();

        });
    }

    // Removes the column and foreign key on rollback
    public function down(): void
    {
        Schema::table('mechanics', function (Blueprint $table) {
            $table->dropForeign(['department_id']);
            $table->dropColumn('department_id');
        });
    }
};