<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    // up() runs when you run: php artisan migrate
    public function up(): void
    {
        Schema::create('mechanics', function (Blueprint $table) {

            // Auto incrementing primary key
            $table->id();

            // String columns with max character lengths
            $table->string('name', 100);
            $table->string('role', 100);
            $table->string('specialism', 100);

            // Integer column for years of experience
            $table->integer('experience')->default(0);

            // Email column
            $table->string('email', 150);

            // Enum restricts values to only these three options
            $table->enum('status', ['Active', 'On Leave', 'Inactive'])->default('Active');

            // Automatically creates created_at and updated_at columns
            $table->timestamps();

        });
    }

    // down() runs when you run: php artisan migrate:rollback
    public function down(): void
    {
        Schema::dropIfExists('mechanics');
    }
};