<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    // Creates the gallery table for uploaded supercar build photos
    public function up(): void
    {
        Schema::create('gallery', function (Blueprint $table) {

            // Auto incrementing primary key
            $table->id();

            // Title and description for each photo
            $table->string('title', 150);

            // nullable() means this column can be empty
            $table->text('description')->nullable();

            // Stores the file path of the uploaded image
            $table->string('image_path')->nullable();

            // Automatically creates created_at and updated_at
            $table->timestamps();

        });
    }

    // Drops the gallery table on rollback
    public function down(): void
    {
        Schema::dropIfExists('gallery');
    }
};