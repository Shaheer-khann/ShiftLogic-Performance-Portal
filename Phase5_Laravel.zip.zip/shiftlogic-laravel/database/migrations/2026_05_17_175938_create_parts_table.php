<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    // Creates the performance parts table
    public function up(): void
    {
        Schema::create('parts', function (Blueprint $table) {

            // Auto incrementing primary key
            $table->id();

            $table->string('name', 150);
            $table->string('category', 100);

            // Decimal for price — 10 total digits, 2 after decimal point
            $table->decimal('price', 10, 2)->default(0.00);

            $table->string('condition_type', 50)->default('New');

            // Text columns for longer content
            $table->text('description');
            $table->text('specs');

            // Automatically creates created_at and updated_at
            $table->timestamps();

        });
    }

    // Drops the parts table on rollback
    public function down(): void
    {
        Schema::dropIfExists('parts');
    }
};