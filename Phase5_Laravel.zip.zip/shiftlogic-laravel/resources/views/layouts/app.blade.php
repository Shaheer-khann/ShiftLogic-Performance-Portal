<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />

    {{-- @yield('title') is a placeholder each page fills in --}}
    <title>@yield('title', 'ShiftLogic') – ShiftLogic</title>

    {{-- Bootstrap CSS --}}
    <link
      rel="stylesheet"
      href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
    />

    {{-- Favicon — appears in the browser tab next to the page title --}}
    {{-- asset('favicon.png') points to public/favicon.png --}}
    <link rel="icon" type="image/png" href="{{ asset('favicon.png') }}" />

    {{-- asset() generates the correct URL to the public folder --}}
    <link rel="stylesheet" href="{{ asset('style.css') }}" />
  </head>
  <body>

    {{-- ===== BOOTSTRAP NAVBAR ===== --}}
    <nav class="navbar navbar-expand-lg" id="mainNavbar">
      <div class="container-fluid">

        {{-- Brand logo — links back to the home page when clicked --}}
        <a class="navbar-brand" href="{{ route('home') }}" id="navbarBrand">

          {{-- asset('logo.png') generates the URL: http://127.0.0.1:8000/logo.png --}}
          {{-- The img is given a fixed height so it fits neatly inside the navbar --}}
          {{-- width="auto" keeps the original aspect ratio — no squishing --}}
          <img
            src="{{ asset('logo.png') }}"
            alt="ShiftLogic Logo"
            height="38"
            width="auto"
          />

        </a>

        {{-- Hamburger button for mobile --}}
        <button
          class="navbar-toggler"
          type="button"
          data-bs-toggle="collapse"
          data-bs-target="#navLinks"
          aria-controls="navLinks"
          aria-expanded="false"
          aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>

        {{-- Nav links --}}
        <div class="collapse navbar-collapse" id="navLinks">
          <ul class="navbar-nav ms-auto">

            <li class="nav-item">
              {{-- route() generates URL from a named route --}}
              <a class="nav-link" href="{{ route('home') }}">Home</a>
            </li>

            <li class="nav-item">
              <a class="nav-link" href="{{ route('crew.index') }}">Crew Directory</a>
            </li>

            <li class="nav-item">
              <a class="nav-link" href="{{ route('parts.index') }}">Performance Parts</a>
            </li>

            <li class="nav-item">
              <a class="nav-link" href="{{ route('gallery.index') }}">Gallery</a>
            </li>

            <li class="nav-item">
              <a class="nav-link" href="{{ route('api.parts') }}">Parts API</a>
            </li>

          </ul>
        </div>

      </div>
    </nav>
    {{-- End Navbar --}}

    {{-- ===== PAGE CONTENT ===== --}}
    {{-- @yield('content') is where each page injects its HTML --}}
    <div id="page-wrapper">
      @yield('content')
    </div>

    {{-- Bootstrap JS --}}
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

    {{-- jQuery --}}
    <script src="https://cdn.jsdelivr.net/npm/jquery@3.7.1/dist/jquery.min.js"></script>

    {{-- Extra scripts each page can optionally add --}}
    @yield('scripts')

  </body>
</html>