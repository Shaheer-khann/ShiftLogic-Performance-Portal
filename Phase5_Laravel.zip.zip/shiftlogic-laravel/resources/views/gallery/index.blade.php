{{-- Extend the master layout --}}
@extends('layouts.app')

{{-- Set the page title --}}
@section('title', 'Gallery')

{{-- Begin the page content --}}
@section('content')

    {{-- ===== PAGE HEADER ===== --}}
    <div id="page-header">
        <h1>Build Gallery</h1>
        <p>Photos from our supercar builds, track days, and workshop projects.</p>
    </div>

    {{-- ===== MAIN CONTENT ===== --}}
    <div id="main-content">

        <div id="gallery-section">

            <div class="section-title">
                <h2>Supercar Builds</h2>
            </div>

            {{-- ===== FLASH SUCCESS MESSAGE ===== --}}
            {{-- session('success') checks for a one-time message stored by the controller --}}
            @if(session('success'))
                <div class="form-success-msg">
                    {{ session('success') }}
                </div>
            @endif

            {{-- ===== UPLOAD BUTTON ===== --}}
            <div style="margin-bottom: 16px;">
                {{-- Link to the gallery upload form page --}}
                <a href="{{ route('gallery.create') }}" class="btn-add-crew">+ Upload Photo</a>
            </div>

            {{-- ===== EMPTY STATE MESSAGE ===== --}}
            {{-- $photos->isEmpty() returns true if the Collection has zero items --}}
            {{-- We show a friendly message rather than an empty grid --}}
            @if($photos->isEmpty())
                <p style="color: #aaa; text-align: center; padding: 40px 0;">
                    No photos uploaded yet. Click "Upload Photo" to add the first one.
                </p>

            {{-- @else runs if $photos is NOT empty (at least one photo exists) --}}
            @else

                {{-- ===== GALLERY GRID ===== --}}
                {{-- #gallery-grid is styled as a CSS grid in style.css --}}
                <div id="gallery-grid">

                    {{-- Loop through every Gallery photo object --}}
                    {{-- $photo is one Gallery object on each loop iteration --}}
                    @foreach($photos as $photo)

                        {{-- ===== GALLERY CARD ===== --}}
                        {{-- .gallery-card wraps one photo entry --}}
                        <div class="gallery-card">

                            {{-- ===== IMAGE WRAPPER ===== --}}
                            {{-- .gallery-image-wrapper contains just the <img> tag --}}
                            <div class="gallery-image-wrapper">
                                {{-- asset('storage/' . $photo->image_path) builds the public URL --}}
                                {{-- e.g. http://127.0.0.1:8000/storage/gallery/abc123.jpg --}}
                                {{-- alt uses the photo title for screen reader accessibility --}}
                                <img
                                    src="{{ asset('storage/' . $photo->image_path) }}"
                                    alt="{{ $photo->title }}"
                                />
                            </div>
                            {{-- End .gallery-image-wrapper --}}

                            {{-- ===== CARD BODY ===== --}}
                            {{-- .gallery-card-body holds the title and description text --}}
                            <div class="gallery-card-body">

                                {{-- Photo title as a subheading --}}
                                <h3>{{ $photo->title }}</h3>

                                {{-- Description is optional so we check if it has a value --}}
                                {{-- $photo->description checks if the column is not null/empty --}}
                                @if($photo->description)
                                    {{-- Output the description text --}}
                                    <p>{{ $photo->description }}</p>
                                @endif

                                {{-- Upload date formatted as day Month Year e.g. "23 May 2026" --}}
                                {{-- $photo->created_at is a Carbon datetime object --}}
                                {{-- ->format('d M Y') converts it to a readable date string --}}
                                <p style="color: #888; font-size: 0.85em;">
                                    Uploaded: {{ $photo->created_at->format('d M Y') }}
                                </p>

                            </div>
                            {{-- End .gallery-card-body --}}

                            {{-- ===== CARD FOOTER ===== --}}
                            {{-- .gallery-card-footer holds the delete button at the bottom --}}
                            <div class="gallery-card-footer">

                                {{-- Delete form — uses POST + @method('DELETE') like in crew --}}
                                <form
                                    action="{{ route('gallery.destroy', $photo->id) }}"
                                    method="POST"
                                >
                                    {{-- CSRF token required on all forms --}}
                                    @csrf

                                    {{-- Spoofs a DELETE request via hidden input --}}
                                    @method('DELETE')

                                    {{-- Delete button with a confirmation popup --}}
                                    <button
                                        type="submit"
                                        class="btn-table-delete"
                                        onclick="return confirm('Delete this photo permanently?')"
                                    >
                                        Delete Photo
                                    </button>

                                </form>

                            </div>
                            {{-- End .gallery-card-footer --}}

                        </div>
                        {{-- End .gallery-card --}}

                    @endforeach
                    {{-- End of gallery photos loop --}}

                </div>
                {{-- End #gallery-grid --}}

            @endif
            {{-- End @if($photos->isEmpty()) --}}

        </div>
        {{-- End #gallery-section --}}

    </div>
    {{-- End #main-content --}}

@endsection
