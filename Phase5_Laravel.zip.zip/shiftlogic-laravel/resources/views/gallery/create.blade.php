{{-- Extend the master layout --}}
@extends('layouts.app')

{{-- Set the page title --}}
@section('title', 'Upload Photo')

{{-- Begin the page content --}}
@section('content')

    {{-- ===== PAGE HEADER ===== --}}
    <div id="page-header">
        <h1>Upload Build Photo</h1>
        <p>Add a new photo to the ShiftLogic supercar build gallery.</p>
    </div>

    {{-- ===== MAIN CONTENT ===== --}}
    <div id="main-content">

        <div id="gallery-upload-section">

            <div class="section-title">
                <h2>Photo Details</h2>
            </div>

            {{-- ===== VALIDATION ERROR BOX ===== --}}
            @if($errors->any())
                <div class="login-error">
                    <ul style="margin: 0; padding-left: 20px;">
                        @foreach($errors->all() as $error)
                            <li>{{ $error }}</li>
                        @endforeach
                    </ul>
                </div>
            @endif

            {{-- ===== UPLOAD FORM ===== --}}
            <div class="form-wrapper">

                {{-- action routes the form submission to GalleryController@store --}}
                {{-- method="POST" is required for creating data --}}
                {{-- enctype="multipart/form-data" is REQUIRED for file uploads --}}
                {{-- Without enctype, the file input is ignored and $request->file() returns null --}}
                <form
                    action="{{ route('gallery.store') }}"
                    method="POST"
                    enctype="multipart/form-data"
                >

                    {{-- CSRF token — required on every form --}}
                    @csrf

                    {{-- ===== TITLE FIELD ===== --}}
                    <div class="form-group">
                        <label for="title">Photo Title:</label>
                        {{-- old('title') repopulates the field if validation failed --}}
                        <input
                            type="text"
                            id="title"
                            name="title"
                            placeholder="e.g. Nissan GT-R Track Build"
                            value="{{ old('title') }}"
                        />
                    </div>

                    {{-- ===== DESCRIPTION FIELD ===== --}}
                    <div class="form-group">
                        <label for="description">Description (optional):</label>
                        {{-- Textarea for longer text — description is not required --}}
                        <textarea
                            id="description"
                            name="description"
                            rows="4"
                            placeholder="Describe the build, modifications, or event..."
                        >{{-- old('description') repopulates after a failed submit --}}{{ old('description') }}</textarea>
                    </div>

                    {{-- ===== IMAGE FILE INPUT ===== --}}
                    <div class="form-group">
                        <label for="image">Select Image:</label>
                        {{-- type="file" creates the file picker button --}}
                        {{-- accept="image/*" limits the file picker to image files only --}}
                        {{-- (jpg, png, gif, webp etc.) — this is client-side only, --}}
                        {{-- Laravel's 'image' validation rule enforces it server-side too --}}
                        <input
                            type="file"
                            id="image"
                            name="image"
                            accept="image/*"
                        />
                        {{-- Helpful hint so the user knows the maximum file size --}}
                        <small style="color: #888;">Maximum file size: 2MB. Supported: JPG, PNG, GIF, WebP.</small>
                    </div>

                    {{-- ===== FORM BUTTONS ===== --}}
                    <div class="form-buttons">
                        <button type="submit">Upload Photo</button>

                        {{-- Cancel returns to the gallery grid without uploading --}}
                        <a href="{{ route('gallery.index') }}" class="btn-cancel">Cancel</a>
                    </div>

                </form>
                {{-- End form --}}

            </div>
            {{-- End .form-wrapper --}}

        </div>
        {{-- End #gallery-upload-section --}}

    </div>
    {{-- End #main-content --}}

@endsection
