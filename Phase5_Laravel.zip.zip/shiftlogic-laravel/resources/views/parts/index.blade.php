{{-- Extend the master layout --}}
@extends('layouts.app')

{{-- Set the page title --}}
@section('title', 'Performance Parts')

{{-- Begin the page content --}}
@section('content')

    {{-- ===== PAGE HEADER ===== --}}
    <div id="page-header">
        <h1>Performance Parts</h1>
        <p>Browse our catalogue of race-grade components available for installation.</p>
    </div>

    {{-- ===== MAIN CONTENT ===== --}}
    <div id="main-content">

        {{-- ===== PARTS SECTION ===== --}}
        {{-- This id matches #parts-section in style.css --}}
        <div id="parts-section">

            <div class="section-title">
                <h2>Parts Catalogue</h2>
            </div>

            {{-- #parts-container is the flex/grid wrapper that holds all the part cards --}}
            {{-- In the legacy app this was filled by JavaScript; now it is filled by Blade --}}
            <div id="parts-container">

                {{-- @foreach loops through every Part object in the $parts collection --}}
                {{-- $part is one Part object on each loop iteration --}}
                @foreach($parts as $part)

                    {{-- ===== INDIVIDUAL PART CARD ===== --}}
                    {{-- .part-card is the main card container styled in style.css --}}
                    <div class="part-card">

                        {{-- ===== CARD HEADER ===== --}}
                        {{-- .part-card-header holds the category and condition badges --}}
                        <div class="part-card-header">

                            {{-- .part-category shows the part's category e.g. "Forced Induction" --}}
                            <span class="part-category">{{ $part->category }}</span>

                            {{-- .part-condition shows whether the part is New or Used --}}
                            {{-- condition_type is the column name in our parts table --}}
                            <span class="part-condition">{{ $part->condition_type }}</span>

                        </div>
                        {{-- End .part-card-header --}}

                        {{-- ===== CARD BODY ===== --}}
                        {{-- .part-card-body holds the part name and description --}}
                        <div class="part-card-body">

                            {{-- Part name as a heading --}}
                            <h3>{{ $part->name }}</h3>

                            {{-- Full description paragraph --}}
                            <p>{{ $part->description }}</p>

                            {{-- ===== SPECS BOX ===== --}}
                            {{-- .specs-box shows the technical specifications --}}
                            {{-- We display this directly in Blade instead of using a jQuery modal --}}
                            <div class="specs-box">
                                {{-- A bold label followed by the specs text --}}
                                <strong>Technical Specs:</strong><br />
                                {{-- $part->specs contains pipe-separated spec strings --}}
                                {{ $part->specs }}
                            </div>
                            {{-- End .specs-box --}}

                        </div>
                        {{-- End .part-card-body --}}

                        {{-- ===== CARD FOOTER ===== --}}
                        {{-- .part-card-footer holds the price at the bottom of the card --}}
                        <div class="part-card-footer">

                            {{-- .part-price shows the formatted price --}}
                            {{-- number_format($part->price, 2) adds commas and 2 decimal places --}}
                            {{-- e.g. 1850.0 → "1,850.00" --}}
                            <span class="part-price">${{ number_format($part->price, 2) }}</span>

                        </div>
                        {{-- End .part-card-footer --}}

                    </div>
                    {{-- End .part-card --}}

                @endforeach
                {{-- @endforeach marks the end of the parts loop --}}

            </div>
            {{-- End #parts-container --}}

        </div>
        {{-- End #parts-section --}}

    </div>
    {{-- End #main-content --}}

@endsection
