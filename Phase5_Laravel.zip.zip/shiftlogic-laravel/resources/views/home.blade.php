{{-- @extends tells Blade this view is a child of the master layout --}}
{{-- It will be injected into layouts/app.blade.php where @yield('content') is --}}
@extends('layouts.app')

{{-- @section fills the @yield('title') placeholder in the layout's <title> tag --}}
@section('title', 'Home')

{{-- @section('content') begins the block of HTML that goes into @yield('content') --}}
@section('content')

    {{-- ===== PAGE HEADER ===== --}}
    {{-- This id matches the #page-header style in public/style.css --}}
    <div id="page-header">

        {{-- The main h1 heading for the landing page --}}
        <h1>ShiftLogic Performance Portal</h1>

        {{-- A short tagline shown below the heading --}}
        <p>Karachi's premier race tuning garage. Built for speed, engineered to win.</p>

    </div>
    {{-- End #page-header --}}

    {{-- ===== MAIN CONTENT AREA ===== --}}
    {{-- The #main-content div wraps all the sections below the header --}}
    <div id="main-content">

        {{-- ===== WELCOME SECTION ===== --}}
        <div id="welcome-section">

            {{-- .section-title wraps every section heading for consistent styling --}}
            <div class="section-title">
                <h2>Welcome to the Garage</h2>
            </div>

            <div class="welcome-text">
                {{-- First paragraph describing the garage --}}
                <p>
                    ShiftLogic is a high-performance tuning garage specializing in
                    supercar builds, engine tuning, and race-day preparation. Our crew
                    of expert mechanics is ready to take your build to the next level.
                </p>

                {{-- Second paragraph with more detail --}}
                <p>
                    Every car that leaves our garage has been through a rigorous
                    tuning process — from ECU mapping and forced induction to full
                    suspension geometry setups. We do not cut corners.
                </p>
            </div>

        </div>
        {{-- End #welcome-section --}}

        {{-- A horizontal rule divider between sections --}}
        <hr />

        {{-- ===== SERVICES SECTION ===== --}}
        <div id="services-section">

            <div class="section-title">
                <h2>Our Services</h2>
            </div>

            {{-- #services-grid is styled as a CSS grid in style.css --}}
            {{-- Each .service-card is one tile in the grid --}}
            <div id="services-grid">

                {{-- Service Card 1 --}}
                <div class="service-card">
                    <h3>Engine Tuning</h3>
                    <p>Full rebuilds, bore-and-stroke work, and power upgrades tailored to your exact setup.</p>
                </div>

                {{-- Service Card 2 --}}
                <div class="service-card">
                    <h3>Turbo &amp; Forced Induction</h3>
                    {{-- &amp; is the HTML entity for the & character — always use it inside HTML text --}}
                    <p>Turbocharger installs, intercooler upgrades, and boost mapping by our specialists.</p>
                </div>

                {{-- Service Card 3 --}}
                <div class="service-card">
                    <h3>ECU Mapping</h3>
                    <p>Custom ECU calibration for maximum power, fuel efficiency, and reliability on track.</p>
                </div>

                {{-- Service Card 4 --}}
                <div class="service-card">
                    <h3>Suspension Setup</h3>
                    <p>Corner-by-corner geometry, coilover installation, and alignment for race conditions.</p>
                </div>

                {{-- Service Card 5 --}}
                <div class="service-card">
                    <h3>Race Preparation</h3>
                    <p>Full pre-race inspection, telemetry review, and race-day pit crew support.</p>
                </div>

                {{-- Service Card 6 --}}
                <div class="service-card">
                    <h3>Supercar Builds</h3>
                    <p>Ground-up custom builds from chassis to finished car, documented with full photo gallery.</p>
                </div>

            </div>
            {{-- End #services-grid --}}

        </div>
        {{-- End #services-section --}}

        <hr />

        {{-- ===== STATS SECTION ===== --}}
        <div id="stats-section">

            <div class="section-title">
                <h2>By the Numbers</h2>
            </div>

            {{-- #stats-grid displays the stat cards in a row --}}
            <div id="stats-grid">

                {{-- Stat Card 1 --}}
                <div class="stat-card">
                    {{-- .stat-number shows the big bold figure --}}
                    <div class="stat-number">400+</div>
                    {{-- .stat-label shows the description below the number --}}
                    <div class="stat-label">Cars Serviced</div>
                </div>

                {{-- Stat Card 2 --}}
                <div class="stat-card">
                    <div class="stat-number">5</div>
                    <div class="stat-label">Specialist Mechanics</div>
                </div>

                {{-- Stat Card 3 --}}
                <div class="stat-card">
                    <div class="stat-number">15+</div>
                    <div class="stat-label">Years in Racing</div>
                </div>

                {{-- Stat Card 4 --}}
                <div class="stat-card">
                    <div class="stat-number">30+</div>
                    <div class="stat-label">Race Wins Supported</div>
                </div>

            </div>
            {{-- End #stats-grid --}}

        </div>
        {{-- End #stats-section --}}

    </div>
    {{-- End #main-content --}}

{{-- @endsection marks the end of the 'content' block --}}
@endsection
