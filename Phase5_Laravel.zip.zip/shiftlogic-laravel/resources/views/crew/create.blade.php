{{-- Extend the master layout --}}
@extends('layouts.app')

{{-- Set the browser tab title --}}
@section('title', 'Add Mechanic')

{{-- Begin the page content --}}
@section('content')

    {{-- ===== PAGE HEADER ===== --}}
    <div id="page-header">
        <h1>Add New Mechanic</h1>
        <p>Fill in the fields below to add a new mechanic to the ShiftLogic crew.</p>
    </div>

    {{-- ===== MAIN CONTENT ===== --}}
    <div id="main-content">

        <div id="crew-form-section">

            <div class="section-title">
                <h2>Mechanic Details</h2>
            </div>

            {{-- ===== VALIDATION ERROR BOX ===== --}}
            {{-- $errors is automatically available in every Blade view --}}
            {{-- $errors->any() returns true if the last form submission had ANY validation failures --}}
            @if($errors->any())
                {{-- .login-error is a red error box already styled in style.css --}}
                <div class="login-error">
                    {{-- $errors->all() returns every error message as a simple array --}}
                    {{-- @foreach loops through and prints each one as a bullet point --}}
                    <ul style="margin: 0; padding-left: 20px;">
                        @foreach($errors->all() as $error)
                            {{-- {{ $error }} outputs the specific error message text --}}
                            <li>{{ $error }}</li>
                        @endforeach
                    </ul>
                </div>
            @endif

            {{-- ===== ADD MECHANIC FORM ===== --}}
            {{-- action="{{ route('crew.store') }}" sends the form data to POST /crew --}}
            {{-- method="POST" is required for creating data (not GET) --}}
            <div class="form-wrapper">
                <form action="{{ route('crew.store') }}" method="POST">

                    {{-- @csrf outputs a hidden security token field --}}
                    {{-- Laravel rejects any POST form that does not include this token --}}
                    @csrf

                    {{-- ===== NAME FIELD ===== --}}
                    <div class="form-group">
                        {{-- The label's for attribute links it to the input's id --}}
                        <label for="name">Full Name:</label>
                        {{-- old('name') repopulates this field if validation failed --}}
                        {{-- If there is no old value it returns null (empty field) --}}
                        <input
                            type="text"
                            id="name"
                            name="name"
                            placeholder="e.g. Darya Khan"
                            value="{{ old('name') }}"
                        />
                    </div>

                    {{-- ===== DEPARTMENT DROPDOWN ===== --}}
                    <div class="form-group">
                        <label for="department_id">Department:</label>
                        {{-- The <select> dropdown is populated from $departments passed by the controller --}}
                        <select id="department_id" name="department_id">
                            {{-- First option is blank — lets the user choose "no department" --}}
                            <option value="">-- No Department --</option>

                            {{-- Loop through every department to create one <option> per department --}}
                            @foreach($departments as $dept)
                                {{-- old('department_id') remembers which option was selected on failed submit --}}
                                {{-- If old value matches this dept's id, add the selected attribute --}}
                                <option
                                    value="{{ $dept->id }}"
                                    {{ old('department_id') == $dept->id ? 'selected' : '' }}
                                >
                                    {{-- Display the department name as the visible option text --}}
                                    {{ $dept->name }}
                                </option>
                            @endforeach

                        </select>
                    </div>

                    {{-- ===== ROLE FIELD ===== --}}
                    <div class="form-group">
                        <label for="role">Role / Job Title:</label>
                        <input
                            type="text"
                            id="role"
                            name="role"
                            placeholder="e.g. Lead Mechanic"
                            value="{{ old('role') }}"
                        />
                    </div>

                    {{-- ===== SPECIALISM FIELD ===== --}}
                    <div class="form-group">
                        <label for="specialism">Specialism:</label>
                        <input
                            type="text"
                            id="specialism"
                            name="specialism"
                            placeholder="e.g. Engine Rebuilds"
                            value="{{ old('specialism') }}"
                        />
                    </div>

                    {{-- ===== EXPERIENCE FIELD ===== --}}
                    <div class="form-group">
                        <label for="experience">Years of Experience:</label>
                        {{-- type="number" creates a numeric input spinner --}}
                        {{-- min and max enforce the same range as the validation rule (0-50) --}}
                        <input
                            type="number"
                            id="experience"
                            name="experience"
                            min="0"
                            max="50"
                            placeholder="e.g. 8"
                            value="{{ old('experience') }}"
                        />
                    </div>

                    {{-- ===== EMAIL FIELD ===== --}}
                    <div class="form-group">
                        <label for="email">Email Address:</label>
                        {{-- type="email" adds browser-level format validation --}}
                        <input
                            type="email"
                            id="email"
                            name="email"
                            placeholder="e.g. darya@shiftlogic.com"
                            value="{{ old('email') }}"
                        />
                    </div>

                    {{-- ===== STATUS DROPDOWN ===== --}}
                    <div class="form-group">
                        <label for="status">Status:</label>
                        <select id="status" name="status">
                            {{-- For each option, check if old('status') matches --}}
                            {{-- If it matches, output the word 'selected' to pre-select it --}}
                            <option value="Active"   {{ old('status') == 'Active'   ? 'selected' : '' }}>Active</option>
                            <option value="On Leave" {{ old('status') == 'On Leave' ? 'selected' : '' }}>On Leave</option>
                            <option value="Inactive" {{ old('status') == 'Inactive' ? 'selected' : '' }}>Inactive</option>
                        </select>
                    </div>

                    {{-- ===== FORM BUTTONS ===== --}}
                    <div class="form-buttons">
                        {{-- type="submit" sends the form when clicked --}}
                        <button type="submit">Add Mechanic</button>

                        {{-- Cancel link goes back to the crew list without submitting --}}
                        {{-- .btn-cancel is a secondary styled button in style.css --}}
                        <a href="{{ route('crew.index') }}" class="btn-cancel">Cancel</a>
                    </div>

                </form>
                {{-- End form --}}
            </div>
            {{-- End .form-wrapper --}}

        </div>
        {{-- End #crew-form-section --}}

    </div>
    {{-- End #main-content --}}

@endsection
