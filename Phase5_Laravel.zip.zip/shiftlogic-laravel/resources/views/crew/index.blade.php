{{-- This view extends the master layout at resources/views/layouts/app.blade.php --}}
@extends('layouts.app')

{{-- Set the page title that fills @yield('title') in the layout --}}
@section('title', 'Crew Directory')

{{-- Begin the main content block --}}
@section('content')

    {{-- ===== PAGE HEADER ===== --}}
    <div id="page-header">
        <h1>Crew Directory</h1>
        <p>Meet the mechanics and engineers behind every ShiftLogic build.</p>
    </div>

    {{-- ===== MAIN CONTENT ===== --}}
    <div id="main-content">

        {{-- ===== CREW TABLE SECTION ===== --}}
        <div id="crew-section">

            <div class="section-title">
                <h2>Active Mechanics &amp; Staff</h2>
            </div>

            {{-- ===== FLASH SUCCESS MESSAGE ===== --}}
            {{-- session('success') reads a one-time message stored in the session --}}
            {{-- It is set by ->with('success', '...') in the controller after a create/update/delete --}}
            {{-- @if checks if the session has a 'success' key --}}
            @if(session('success'))
                {{-- .form-success-msg is a green success box styled in style.css --}}
                <div class="form-success-msg">
                    {{-- {{ }} safely outputs the session message --}}
                    {{ session('success') }}
                </div>
            @endif
            {{-- @endif closes the @if block --}}

            {{-- ===== ADD NEW MECHANIC BUTTON ===== --}}
            <div style="margin-bottom: 16px;">
                {{-- route('crew.create') generates the URL /crew/create --}}
                {{-- .btn-add-crew gives it the green button style from style.css --}}
                <a href="{{ route('crew.create') }}" class="btn-add-crew">+ Add New Mechanic</a>
            </div>

            {{-- ===== MECHANICS TABLE ===== --}}
            <div class="table-wrapper">
                <table>

                    {{-- Table header row with column labels --}}
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Name</th>
                            <th>Department</th>
                            <th>Role</th>
                            <th>Specialism</th>
                            <th>Experience</th>
                            <th>Email</th>
                            <th>Status</th>
                            <th>Actions</th>
                        </tr>
                    </thead>

                    {{-- Table body — one row per mechanic --}}
                    <tbody>

                        {{-- @foreach loops through every mechanic in the $mechanics collection --}}
                        {{-- $mechanic is one mechanic object on each iteration of the loop --}}
                        @foreach($mechanics as $mechanic)
                            <tr>

                                {{-- Output the mechanic's auto-incremented primary key --}}
                                <td>{{ $mechanic->id }}</td>

                                {{-- {{ }} automatically escapes special characters to prevent XSS attacks --}}
                                <td>{{ $mechanic->name }}</td>

                                {{-- optional() safely accesses the department relationship --}}
                                {{-- If department_id is null the relationship returns null --}}
                                {{-- optional(null)->name returns null instead of crashing --}}
                                {{-- ?? 'Unassigned' means "if null, show this fallback text" --}}
                                <td>{{ optional($mechanic->department)->name ?? 'Unassigned' }}</td>

                                <td>{{ $mechanic->role }}</td>
                                <td>{{ $mechanic->specialism }}</td>

                                {{-- Append the word "years" after the integer value --}}
                                <td>{{ $mechanic->experience }} years</td>

                                <td>{{ $mechanic->email }}</td>

                                {{-- ===== STATUS BADGE ===== --}}
                                <td>
                                    {{-- Use a ternary operator to pick the correct CSS class --}}
                                    {{-- Ternary: condition ? value_if_true : value_if_false --}}
                                    {{-- .status-active is green; .status-leave is yellow/orange --}}
                                    <span class="{{ $mechanic->status === 'Active' ? 'status-active' : 'status-leave' }}">
                                        {{ $mechanic->status }}
                                    </span>
                                </td>

                                {{-- ===== ACTION BUTTONS ===== --}}
                                <td>

                                    {{-- Edit button — links to the edit form for this mechanic --}}
                                    {{-- route('crew.edit', $mechanic->id) generates /crew/1/edit --}}
                                    <a href="{{ route('crew.edit', $mechanic->id) }}" class="btn-table-edit">Edit</a>

                                    {{-- Delete form — HTML forms can only do GET and POST --}}
                                    {{-- @method('DELETE') adds a hidden field that tells Laravel --}}
                                    {{-- to treat this POST request as a DELETE request --}}
                                    <form
                                        action="{{ route('crew.destroy', $mechanic->id) }}"
                                        method="POST"
                                        style="display: inline;"
                                    >
                                        {{-- @csrf outputs a hidden token that protects against CSRF attacks --}}
                                        {{-- Laravel will reject any form submission without this token --}}
                                        @csrf

                                        {{-- @method('DELETE') outputs <input type="hidden" name="_method" value="DELETE"> --}}
                                        {{-- This tricks Laravel into routing this POST to the destroy() method --}}
                                        @method('DELETE')

                                        {{-- onclick="return confirm(...)" shows a browser popup before submitting --}}
                                        {{-- If the user clicks Cancel, return false stops the form submission --}}
                                        <button
                                            type="submit"
                                            class="btn-table-delete"
                                            onclick="return confirm('Are you sure you want to remove {{ $mechanic->name }}?')"
                                        >
                                            Delete
                                        </button>

                                    </form>
                                    {{-- End delete form --}}

                                </td>
                                {{-- End actions cell --}}

                            </tr>
                        @endforeach
                        {{-- @endforeach marks the end of the loop --}}

                    </tbody>
                </table>
            </div>
            {{-- End .table-wrapper --}}

        </div>
        {{-- End #crew-section --}}

        <hr />

        {{-- ===== DEPARTMENTS SUMMARY SECTION ===== --}}
        <div id="departments-section">

            <div class="section-title">
                <h2>Departments</h2>
            </div>

            <div class="departments-wrapper">
                <ol class="departments-list">

                    {{-- Loop through each department passed from the controller --}}
                    {{-- $dept is one Department object on each loop iteration --}}
                    @foreach($departments as $dept)
                        <li>
                            {{-- Output the department name --}}
                            {{ $dept->name }}

                            {{-- $dept->mechanics is the loaded Collection of mechanics in this dept --}}
                            {{-- ->count() returns how many mechanics are in that collection --}}
                            {{-- We wrap it in parentheses for readability --}}
                            ({{ $dept->mechanics->count() }}
                            {{-- Pluralise "mechanic" correctly based on the count --}}
                            {{ $dept->mechanics->count() === 1 ? 'mechanic' : 'mechanics' }})
                        </li>
                    @endforeach

                </ol>
            </div>

        </div>
        {{-- End #departments-section --}}

    </div>
    {{-- End #main-content --}}

@endsection
