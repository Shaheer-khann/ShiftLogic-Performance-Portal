{{-- Extend the master layout --}}
@extends('layouts.app')

{{-- Set the browser tab title --}}
@section('title', 'Edit Mechanic')

{{-- Begin the page content --}}
@section('content')

    {{-- ===== PAGE HEADER ===== --}}
    <div id="page-header">
        {{-- The mechanic's name is shown in the heading for clarity --}}
        <h1>Edit Mechanic</h1>
        {{-- {{ $mechanic->name }} outputs the name of the mechanic being edited --}}
        <p>Editing record for: <strong>{{ $mechanic->name }}</strong></p>
    </div>

    {{-- ===== MAIN CONTENT ===== --}}
    <div id="main-content">

        <div id="crew-form-section">

            <div class="section-title">
                <h2>Update Mechanic Details</h2>
            </div>

            {{-- ===== VALIDATION ERROR BOX ===== --}}
            {{-- Same as create.blade.php — shows red error box if any validation failed --}}
            @if($errors->any())
                <div class="login-error">
                    <ul style="margin: 0; padding-left: 20px;">
                        @foreach($errors->all() as $error)
                            <li>{{ $error }}</li>
                        @endforeach
                    </ul>
                </div>
            @endif

            {{-- ===== EDIT MECHANIC FORM ===== --}}
            <div class="form-wrapper">

                {{-- route('crew.update', $mechanic->id) generates PUT /crew/1 --}}
                {{-- method="POST" is required because HTML forms cannot send PUT directly --}}
                {{-- @method('PUT') adds the hidden field that tricks Laravel into routing this as PUT --}}
                <form action="{{ route('crew.update', $mechanic->id) }}" method="POST">

                    {{-- Security token required on every form --}}
                    @csrf

                    {{-- @method('PUT') outputs: <input type="hidden" name="_method" value="PUT"> --}}
                    {{-- This tells the CrewController router to call update() not store() --}}
                    @method('PUT')

                    {{-- ===== NAME FIELD ===== --}}
                    <div class="form-group">
                        <label for="name">Full Name:</label>
                        {{-- old('name', $mechanic->name) means: --}}
                        {{--   - If form was just submitted and failed validation: use old submitted value --}}
                        {{--   - If this is the first page load: use $mechanic->name from the database --}}
                        <input
                            type="text"
                            id="name"
                            name="name"
                            value="{{ old('name', $mechanic->name) }}"
                        />
                    </div>

                    {{-- ===== DEPARTMENT DROPDOWN ===== --}}
                    <div class="form-group">
                        <label for="department_id">Department:</label>
                        <select id="department_id" name="department_id">

                            {{-- Blank option for "no department assigned" --}}
                            <option value="">-- No Department --</option>

                            {{-- Loop through all departments to build the dropdown --}}
                            @foreach($departments as $dept)
                                <option
                                    value="{{ $dept->id }}"
                                    {{-- old() with fallback to mechanic's current department_id --}}
                                    {{-- This pre-selects the department the mechanic currently belongs to --}}
                                    {{ old('department_id', $mechanic->department_id) == $dept->id ? 'selected' : '' }}
                                >
                                    {{ $dept->name }}
                                </option>
                            @endforeach

                        </select>
                    </div>

                    {{-- ===== ROLE FIELD ===== --}}
                    <div class="form-group">
                        <label for="role">Role / Job Title:</label>
                        <input
                            type="text"
                            id="role"
                            name="role"
                            value="{{ old('role', $mechanic->role) }}"
                        />
                    </div>

                    {{-- ===== SPECIALISM FIELD ===== --}}
                    <div class="form-group">
                        <label for="specialism">Specialism:</label>
                        <input
                            type="text"
                            id="specialism"
                            name="specialism"
                            value="{{ old('specialism', $mechanic->specialism) }}"
                        />
                    </div>

                    {{-- ===== EXPERIENCE FIELD ===== --}}
                    <div class="form-group">
                        <label for="experience">Years of Experience:</label>
                        <input
                            type="number"
                            id="experience"
                            name="experience"
                            min="0"
                            max="50"
                            value="{{ old('experience', $mechanic->experience) }}"
                        />
                    </div>

                    {{-- ===== EMAIL FIELD ===== --}}
                    <div class="form-group">
                        <label for="email">Email Address:</label>
                        <input
                            type="email"
                            id="email"
                            name="email"
                            value="{{ old('email', $mechanic->email) }}"
                        />
                    </div>

                    {{-- ===== STATUS DROPDOWN ===== --}}
                    <div class="form-group">
                        <label for="status">Status:</label>
                        <select id="status" name="status">
                            {{-- old('status', $mechanic->status) checks old value first, --}}
                            {{-- then falls back to the mechanic's current status from the database --}}
                            <option value="Active"   {{ old('status', $mechanic->status) == 'Active'   ? 'selected' : '' }}>Active</option>
                            <option value="On Leave" {{ old('status', $mechanic->status) == 'On Leave' ? 'selected' : '' }}>On Leave</option>
                            <option value="Inactive" {{ old('status', $mechanic->status) == 'Inactive' ? 'selected' : '' }}>Inactive</option>
                        </select>
                    </div>

                    {{-- ===== FORM BUTTONS ===== --}}
                    <div class="form-buttons">
                        {{-- The submit button label says Save Changes instead of Add --}}
                        <button type="submit">Save Changes</button>

                        {{-- Cancel link returns to the crew list without saving --}}
                        <a href="{{ route('crew.index') }}" class="btn-cancel">Cancel</a>
                    </div>

                </form>
                {{-- End form --}}

            </div>
            {{-- End .form-wrapper --}}

        </div>
        {{-- End #crew-form-section --}}

    </div>
    {{-- End #main-content --}}

@endsection
