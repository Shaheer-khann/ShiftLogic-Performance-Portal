<?php $__env->startSection('title', 'Gallery'); ?>


<?php $__env->startSection('content'); ?>

    
    <div id="page-header">
        <h1>Build Gallery</h1>
        <p>Photos from our supercar builds, track days, and workshop projects.</p>
    </div>

    
    <div id="main-content">

        <div id="gallery-section">

            <div class="section-title">
                <h2>Supercar Builds</h2>
            </div>

            
            
            <?php if(session('success')): ?>
                <div class="form-success-msg">
                    <?php echo e(session('success')); ?>

                </div>
            <?php endif; ?>

            
            <div style="margin-bottom: 16px;">
                
                <a href="<?php echo e(route('gallery.create')); ?>" class="btn-add-crew">+ Upload Photo</a>
            </div>

            
            
            
            <?php if($photos->isEmpty()): ?>
                <p style="color: #aaa; text-align: center; padding: 40px 0;">
                    No photos uploaded yet. Click "Upload Photo" to add the first one.
                </p>

            
            <?php else: ?>

                
                
                <div id="gallery-grid">

                    
                    
                    <?php $__currentLoopData = $photos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $photo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        
                        
                        <div class="gallery-card">

                            
                            
                            <div class="gallery-image-wrapper">
                                
                                
                                
                                <img
                                    src="<?php echo e(asset('storage/' . $photo->image_path)); ?>"
                                    alt="<?php echo e($photo->title); ?>"
                                />
                            </div>
                            

                            
                            
                            <div class="gallery-card-body">

                                
                                <h3><?php echo e($photo->title); ?></h3>

                                
                                
                                <?php if($photo->description): ?>
                                    
                                    <p><?php echo e($photo->description); ?></p>
                                <?php endif; ?>

                                
                                
                                
                                <p style="color: #888; font-size: 0.85em;">
                                    Uploaded: <?php echo e($photo->created_at->format('d M Y')); ?>

                                </p>

                            </div>
                            

                            
                            
                            <div class="gallery-card-footer">

                                
                                <form
                                    action="<?php echo e(route('gallery.destroy', $photo->id)); ?>"
                                    method="POST"
                                >
                                    
                                    <?php echo csrf_field(); ?>

                                    
                                    <?php echo method_field('DELETE'); ?>

                                    
                                    <button
                                        type="submit"
                                        class="btn-table-delete"
                                        onclick="return confirm('Delete this photo permanently?')"
                                    >
                                        Delete Photo
                                    </button>

                                </form>

                            </div>
                            

                        </div>
                        

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    

                </div>
                

            <?php endif; ?>
            

        </div>
        

    </div>
    

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\shiftlogic-laravel\resources\views/gallery/index.blade.php ENDPATH**/ ?>