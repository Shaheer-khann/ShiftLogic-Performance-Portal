<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />

    
    <title><?php echo $__env->yieldContent('title', 'ShiftLogic'); ?> – ShiftLogic</title>

    
    <link
      rel="stylesheet"
      href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
    />

    
    
    <link rel="icon" type="image/png" href="<?php echo e(asset('favicon.png')); ?>" />

    
    <link rel="stylesheet" href="<?php echo e(asset('style.css')); ?>" />
  </head>
  <body>

    
    <nav class="navbar navbar-expand-lg" id="mainNavbar">
      <div class="container-fluid">

        
        <a class="navbar-brand" href="<?php echo e(route('home')); ?>" id="navbarBrand">

          
          
          
          <img
            src="<?php echo e(asset('logo.png')); ?>"
            alt="ShiftLogic Logo"
            height="38"
            width="auto"
          />

        </a>

        
        <button
          class="navbar-toggler"
          type="button"
          data-bs-toggle="collapse"
          data-bs-target="#navLinks"
          aria-controls="navLinks"
          aria-expanded="false"
          aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>

        
        <div class="collapse navbar-collapse" id="navLinks">
          <ul class="navbar-nav ms-auto">

            <li class="nav-item">
              
              <a class="nav-link" href="<?php echo e(route('home')); ?>">Home</a>
            </li>

            <li class="nav-item">
              <a class="nav-link" href="<?php echo e(route('crew.index')); ?>">Crew Directory</a>
            </li>

            <li class="nav-item">
              <a class="nav-link" href="<?php echo e(route('parts.index')); ?>">Performance Parts</a>
            </li>

            <li class="nav-item">
              <a class="nav-link" href="<?php echo e(route('gallery.index')); ?>">Gallery</a>
            </li>

            <li class="nav-item">
              <a class="nav-link" href="<?php echo e(route('api.parts')); ?>">Parts API</a>
            </li>

          </ul>
        </div>

      </div>
    </nav>
    

    
    
    <div id="page-wrapper">
      <?php echo $__env->yieldContent('content'); ?>
    </div>

    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

    
    <script src="https://cdn.jsdelivr.net/npm/jquery@3.7.1/dist/jquery.min.js"></script>

    
    <?php echo $__env->yieldContent('scripts'); ?>

  </body>
</html><?php /**PATH C:\xampp\htdocs\shiftlogic-laravel\resources\views/layouts/app.blade.php ENDPATH**/ ?>