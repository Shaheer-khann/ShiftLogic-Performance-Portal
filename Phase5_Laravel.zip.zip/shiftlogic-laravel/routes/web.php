<?php

// Every route file starts by importing the Route facade
// Route:: is how we register URLs the application will respond to
use Illuminate\Support\Facades\Route;

// Import each controller class so we can reference them in routes below
// Without these imports Laravel would not know where to find the class
use App\Http\Controllers\HomeController;    // handles the landing page
use App\Http\Controllers\CrewController;    // handles crew directory and CRUD
use App\Http\Controllers\PartsController;   // handles performance parts catalogue
use App\Http\Controllers\GalleryController; // handles supercar build photo gallery
use App\Http\Controllers\ApiController;     // handles JSON API endpoints

// ================================================================
// HOME ROUTE
// GET / → calls HomeController@index → loads resources/views/home.blade.php
// ->name('home') gives this route the name "home" so we can write route('home') in views
// ================================================================
Route::get('/', [HomeController::class, 'index'])->name('home');

// ================================================================
// CREW RESOURCE ROUTES
// Route::resource registers all 7 RESTful routes for crew in one line:
//   GET    /crew              → crew.index   (list all mechanics)
//   GET    /crew/create       → crew.create  (show add form)
//   POST   /crew              → crew.store   (save new mechanic)
//   GET    /crew/{crew}       → crew.show    (view one mechanic)
//   GET    /crew/{crew}/edit  → crew.edit    (show edit form)
//   PUT    /crew/{crew}       → crew.update  (save edits)
//   DELETE /crew/{crew}       → crew.destroy (delete mechanic)
// ================================================================
Route::resource('crew', CrewController::class);

// ================================================================
// PARTS ROUTE
// GET /parts → calls PartsController@index → loads resources/views/parts/index.blade.php
// ================================================================
Route::get('/parts', [PartsController::class, 'index'])->name('parts.index');

// ================================================================
// GALLERY ROUTES
// We define these individually because we only need 4 of the 7 CRUD actions
// (no show page, no edit page for gallery — just list, upload, and delete)
// ================================================================

// GET /gallery → shows all uploaded photos (the gallery grid page)
Route::get('/gallery', [GalleryController::class, 'index'])->name('gallery.index');

// GET /gallery/upload → shows the photo upload form
// IMPORTANT: this route must be defined BEFORE /gallery/{gallery}
// otherwise Laravel would try to match "upload" as a gallery ID
Route::get('/gallery/upload', [GalleryController::class, 'create'])->name('gallery.create');

// POST /gallery → receives the submitted upload form and saves the photo
Route::post('/gallery', [GalleryController::class, 'store'])->name('gallery.store');

// DELETE /gallery/{gallery} → deletes the photo file and its database record
// {gallery} is a route parameter — Laravel uses route model binding to automatically
// fetch the Gallery object whose id matches the value in the URL
Route::delete('/gallery/{gallery}', [GalleryController::class, 'destroy'])->name('gallery.destroy');

// ================================================================
// API ROUTE
// GET /api/parts → returns all parts as a JSON response (no HTML view)
// This is used by the "Parts API" link in the navbar and by JavaScript fetch calls
// ================================================================
Route::get('/api/parts', [ApiController::class, 'parts'])->name('api.parts');
